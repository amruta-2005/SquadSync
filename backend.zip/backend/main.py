"""
FastAPI Server for SquadSync — Dynamic Collaboration, Workload & Risk Intelligence Platform.
Provides multi-tenant team management, invitation workflows, database-backed task management,
GitHub repository integration, contributor mapping, and explainable analytics.
"""

import csv
import io
import time
import sys
import json
import sqlite3
from pathlib import Path
from typing import Optional, Dict, Any, List
from fastapi import FastAPI, Depends, HTTPException, status, Header, UploadFile, File, Request, Response, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Ensure backend directory is in sys.path regardless of execution CWD
backend_dir = str(Path(__file__).parent.resolve())
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

# Load environment variables
load_dotenv(Path(__file__).parent.parent / ".env")
load_dotenv(Path(__file__).parent / ".env")

from auth import (
    create_user,
    authenticate_user,
    create_session,
    invalidate_session,
    require_authenticated_user,
    set_session_cookies,
    clear_session_cookies,
    SESSION_COOKIE_NAME
)
from github_client import validate_repository, fetch_full_repository_data
from analytics import calculate_analytics
from database import (
    DB_PATH,
    save_repository_config,
    get_repository_config,
    get_internal_repo_credentials,
    update_repository_sync_snapshot,
    get_latest_analytics,
    save_team_tasks,
    get_team_tasks,
    # Team Management
    create_team,
    update_team,
    get_team_by_id,
    get_user_teams,
    get_team_members,
    get_team_membership,
    update_member_role,
    update_member_github_username,
    remove_team_member,
    # Invitations
    create_team_invitation,
    get_team_invitations,
    get_user_pending_invitations,
    respond_to_invitation,
    # Task Management
    create_task,
    get_team_tasks_db,
    get_task_by_id,
    update_task_db,
    delete_task_db
)

app = FastAPI(
    title="SquadSync API",
    description="Dynamic Backend API for SquadSync Collaboration, Workload & Risk Platform",
    version="2.1.0"
)

# Configure CORS with regex to allow local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000"
    ],
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------- Request / Response Models -----------------

class RegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: str = Field(..., min_length=5, max_length=150)
    password: str = Field(..., min_length=8)
    role: Optional[str] = "Student Contributor"

class LoginRequest(BaseModel):
    email: str = Field(..., min_length=5, max_length=150)
    password: str
    remember_me: Optional[bool] = False

class CreateTeamRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    description: Optional[str] = ""

class UpdateTeamRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    description: Optional[str] = ""

class InviteMemberRequest(BaseModel):
    email: str = Field(..., min_length=5, max_length=150)
    role: Optional[str] = "developer"

class RespondInvitationRequest(BaseModel):
    action: str = Field(..., description="Action must be 'accept' or 'decline'")

class UpdateRoleRequest(BaseModel):
    role: str = Field(..., description="Role must be team_lead, developer, reviewer, or viewer")

class UpdateGithubMappingRequest(BaseModel):
    github_username: str = Field(..., min_length=1, max_length=100)

class CreateTaskRequest(BaseModel):
    title: str = Field(..., min_length=2, max_length=200)
    description: Optional[str] = ""
    assignee_id: Optional[str] = None
    priority: Optional[str] = "Medium"
    status: Optional[str] = "Todo"
    story_points: Optional[float] = 1.0
    estimated_hours: Optional[float] = 0.0
    due_date: Optional[str] = None

class UpdateTaskRequest(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    assignee_id: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    story_points: Optional[float] = None
    estimated_hours: Optional[float] = None
    due_date: Optional[str] = None

class UpdateTaskStatusRequest(BaseModel):
    status: str

class ConnectRepoRequest(BaseModel):
    repo_owner: str = Field(..., min_length=1, max_length=100)
    repo_name: str = Field(..., min_length=1, max_length=100)
    branch: Optional[str] = "main"
    github_token: Optional[str] = None

# ----------------- Authorization Guards -----------------

def check_team_access(team_id: str, user_id: str) -> Dict[str, Any]:
    """Ensures that the user belongs to the specified team workspace."""
    membership = get_team_membership(team_id, user_id)
    if not membership:
        # Check if team exists
        team = get_team_by_id(team_id)
        if not team:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Team '{team_id}' not found."
            )
        # Check if user is the creator
        if team.get("created_by") == user_id:
            return {"role": "team_lead", "team_id": team_id, "user_id": user_id}
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to access this team workspace."
        )
    return dict(membership)

def check_team_lead(team_id: str, user_id: str) -> Dict[str, Any]:
    """Ensures that the user has Team Lead authorization for administrative actions."""
    membership = check_team_access(team_id, user_id)
    team = get_team_by_id(team_id)
    is_creator = team and team.get("created_by") == user_id
    if membership.get("role") != "team_lead" and not is_creator:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Team Lead authorization required for this action."
        )
    return membership

# ----------------- Root & Health -----------------

@app.get("/")
def api_root():
    return {
        "service": "SquadSync Collaboration Intelligence API",
        "version": "2.1.0",
        "status": "online",
        "docs_url": "/docs",
        "health_url": "/api/v1/health"
    }

@app.get("/api/v1/health")
def health_check():
    return {
        "status": "healthy",
        "service": "squadsync-backend",
        "timestamp": int(time.time()),
        "auth_enabled": True,
        "github_integration_enabled": True,
        "multi_tenant_teams_enabled": True
    }

# ----------------- Auth Endpoints -----------------

@app.post("/api/v1/auth/register", status_code=status.HTTP_201_CREATED)
def register(req: RegisterRequest, response: Response):
    user = create_user(
        name=req.name,
        email=req.email,
        password=req.password,
        role=req.role or "Student Contributor"
    )
    token, csrf_token, expires_in = create_session(user["id"], remember_me=False)
    set_session_cookies(response, token, csrf_token, expires_in)

    # Check if there are pending invitations for this new user's email
    pending = get_user_pending_invitations(user["email"])
    for inv in pending:
        try:
            respond_to_invitation(inv["id"], user["id"], user["email"], "accept")
        except Exception:
            pass

    return {
        "user": user,
        "token": token,
        "csrf_token": csrf_token,
        "token_type": "bearer",
        "expires_in": expires_in,
        "message": "Account created successfully"
    }

@app.post("/api/v1/auth/login")
def login(req: LoginRequest, request: Request, response: Response):
    client_ip = request.client.host if request.client else "127.0.0.1"
    user = authenticate_user(req.email, req.password, client_ip=client_ip)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password. Please verify your credentials."
        )

    token, csrf_token, expires_in = create_session(user["id"], remember_me=req.remember_me)
    set_session_cookies(response, token, csrf_token, expires_in)

    return {
        "user": user,
        "token": token,
        "csrf_token": csrf_token,
        "token_type": "bearer",
        "expires_in": expires_in,
        "message": f"Welcome back, {user['name']}!"
    }

@app.get("/api/v1/auth/me")
def get_me(user: Dict[str, Any] = Depends(require_authenticated_user)):
    return {
        "user": user,
        "authenticated": True
    }

@app.post("/api/v1/auth/logout")
def logout(request: Request, response: Response, authorization: Optional[str] = Header(None)):
    token = request.cookies.get(SESSION_COOKIE_NAME)
    if not token and authorization and authorization.startswith("Bearer "):
        token = authorization.split("Bearer ", 1)[1].strip()

    if token:
        invalidate_session(token)

    clear_session_cookies(response)
    return {"success": True, "message": "Successfully signed out"}

# ----------------- Helper: Recalculate & Synchronize -----------------

def _recalculate_analytics_with_cached_github(user_id: str, team_id: str):
    """Recompute analytics when tasks or mappings change, using cached raw GitHub data if available."""
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT raw_data_json FROM repositories WHERE team_id = ?", (team_id,))
        row = c.fetchone()
        conn.close()

        raw_github = json.loads(row["raw_data_json"]) if (row and row["raw_data_json"]) else {
            "repository": {}, "contributors": [], "commits": [], "branches": [], "pull_requests": [], "branch_comparisons": {}, "issues": []
        }

        custom_tasks = get_team_tasks(team_id)
        team_members = get_team_members(team_id)

        analytics_result = calculate_analytics(
            github_data=raw_github,
            custom_tasks=custom_tasks,
            team_members=team_members
        )

        update_repository_sync_snapshot(
            user_id=user_id,
            team_id=team_id,
            raw_data=raw_github,
            analytics_data=analytics_result,
            sync_status="success",
            sync_message="Analytics recalibrated with latest tasks and member data"
        )
    except Exception:
        pass

def _sync_repository_internal(user_id: str, team_id: str) -> Dict[str, Any]:
    """Helper to fetch and calculate analytics for a team's configured repository."""
    creds = get_internal_repo_credentials(user_id, team_id)
    if not creds:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"No GitHub repository configured for team '{team_id}'. Please configure a repository in Data Sources."
        )

    owner = creds["repo_owner"]
    repo = creds["repo_name"]
    branch = creds["default_branch"]
    token = creds["github_token"]

    # 1. Fetch live data from GitHub
    try:
        raw_github = fetch_full_repository_data(owner=owner, repo=repo, default_branch=branch, token=token)
    except Exception as e:
        err_msg = str(e)
        update_repository_sync_snapshot(
            user_id=user_id,
            team_id=team_id,
            raw_data={},
            analytics_data={},
            sync_status="error",
            sync_message=f"Sync failed: {err_msg}"
        )
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Failed to fetch data from GitHub: {err_msg}"
        )

    # 2. Retrieve database tasks & official team members
    custom_tasks = get_team_tasks(team_id)
    team_members = get_team_members(team_id)

    # 3. Calculate dynamic analytics
    analytics_result = calculate_analytics(
        github_data=raw_github,
        custom_tasks=custom_tasks,
        team_members=team_members
    )

    # 4. Update snapshot in SQLite
    update_repository_sync_snapshot(
        user_id=user_id,
        team_id=team_id,
        raw_data=raw_github,
        analytics_data=analytics_result,
        sync_status="success",
        sync_message="Data synchronized successfully"
    )

    return analytics_result

# ----------------- FEATURE 1: Team Management -----------------

@app.get("/api/v1/teams")
def get_teams(user: Dict[str, Any] = Depends(require_authenticated_user)):
    user_id = user["id"]
    teams_list = get_user_teams(user_id)
    return {"data": teams_list}

@app.post("/api/v1/teams", status_code=status.HTTP_201_CREATED)
def create_new_team(req: CreateTeamRequest, user: Dict[str, Any] = Depends(require_authenticated_user)):
    team = create_team(
        user_id=user["id"],
        name=req.name,
        description=req.description or ""
    )
    return {
        "success": True,
        "message": f"Team '{team['name']}' created successfully.",
        "data": team
    }

@app.get("/api/v1/teams/{team_id}")
def get_team_details(team_id: str, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_access(team_id, user["id"])
    team = get_team_by_id(team_id)
    if not team:
        raise HTTPException(status_code=404, detail="Team not found")
    members = get_team_members(team_id)
    config = get_repository_config(user["id"], team_id)
    return {
        "data": {
            **team,
            "members": members,
            "repository": config["repository"] if config else None,
            "is_configured": bool(config)
        }
    }

@app.put("/api/v1/teams/{team_id}")
def update_team_details(team_id: str, req: UpdateTeamRequest, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_lead(team_id, user["id"])
    updated = update_team(team_id, name=req.name, description=req.description)
    if not updated:
        raise HTTPException(status_code=404, detail="Team not found")
    return {
        "success": True,
        "message": "Team details updated successfully.",
        "data": updated
    }

@app.get("/api/v1/teams/{team_id}/members")
def list_team_members(team_id: str, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_access(team_id, user["id"])
    members = get_team_members(team_id)
    return {"data": members}

@app.put("/api/v1/teams/{team_id}/members/{member_id}/role")
def change_member_role(team_id: str, member_id: str, req: UpdateRoleRequest, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_lead(team_id, user["id"])
    if req.role not in ["team_lead", "developer", "reviewer", "viewer"]:
        raise HTTPException(status_code=400, detail="Invalid role specified.")
    update_member_role(team_id, member_id, req.role)
    return {
        "success": True,
        "message": f"Updated member role to {req.role}."
    }

@app.put("/api/v1/teams/{team_id}/members/{member_id}/github")
def map_member_github_username(
    team_id: str,
    member_id: str,
    req: UpdateGithubMappingRequest,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    # Allow team lead or self
    if user["id"] != member_id:
        check_team_lead(team_id, user["id"])
    else:
        check_team_access(team_id, user["id"])

    gh_clean = req.github_username.strip().lstrip("@")
    update_member_github_username(team_id, member_id, gh_clean)

    # Trigger analytics recalibration with mapped contributor
    _recalculate_analytics_with_cached_github(user["id"], team_id)

    return {
        "success": True,
        "message": f"Mapped team member to GitHub user '@{gh_clean}' successfully.",
        "github_username": gh_clean
    }

@app.delete("/api/v1/teams/{team_id}/members/{member_id}")
def remove_member(team_id: str, member_id: str, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_lead(team_id, user["id"])
    if user["id"] == member_id:
        raise HTTPException(status_code=400, detail="Team leads cannot remove themselves. Reassign team lead role first.")
    remove_team_member(team_id, member_id)
    _recalculate_analytics_with_cached_github(user["id"], team_id)
    return {
        "success": True,
        "message": "Team member removed successfully."
    }

# ----------------- Invitations -----------------

@app.post("/api/v1/teams/{team_id}/invitations", status_code=status.HTTP_201_CREATED)
def invite_member_to_team(team_id: str, req: InviteMemberRequest, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_lead(team_id, user["id"])
    # Check if already a member
    members = get_team_members(team_id)
    if any(m["email"].lower() == req.email.strip().lower() for m in members):
        raise HTTPException(status_code=400, detail="User is already an active member of this team.")

    invitation = create_team_invitation(
        team_id=team_id,
        invited_by=user["id"],
        email=req.email,
        role=req.role or "developer"
    )

    return {
        "success": True,
        "message": f"Invitation generated for {req.email}.",
        "data": invitation
    }

@app.get("/api/v1/teams/{team_id}/invitations")
def list_team_invitations(team_id: str, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_access(team_id, user["id"])
    invitations = get_team_invitations(team_id)
    return {"data": invitations}

@app.get("/api/v1/invitations/pending")
def list_my_pending_invitations(user: Dict[str, Any] = Depends(require_authenticated_user)):
    invitations = get_user_pending_invitations(user["email"])
    return {"data": invitations}

@app.post("/api/v1/invitations/{invitation_id}/respond")
def respond_invitation_route(invitation_id: str, req: RespondInvitationRequest, user: Dict[str, Any] = Depends(require_authenticated_user)):
    if req.action not in ["accept", "decline"]:
        raise HTTPException(status_code=400, detail="Action must be 'accept' or 'decline'.")
    try:
        res = respond_to_invitation(
            invitation_id=invitation_id,
            user_id=user["id"],
            user_email=user["email"],
            action=req.action
        )
        return res
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

# ----------------- FEATURE 2: Task Management -----------------

@app.get("/api/v1/teams/{team_id}/tasks")
def list_tasks(
    team_id: str,
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    assignee_id: Optional[str] = Query(None),
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    tasks_list = get_team_tasks_db(team_id, status=status, priority=priority, assignee_id=assignee_id)
    return {"data": tasks_list}

@app.post("/api/v1/teams/{team_id}/tasks", status_code=status.HTTP_201_CREATED)
def create_new_task(
    team_id: str,
    req: CreateTaskRequest,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    task = create_task(
        team_id=team_id,
        created_by=user["id"],
        title=req.title,
        description=req.description or "",
        assignee_id=req.assignee_id,
        priority=req.priority or "Medium",
        status=req.status or "Todo",
        story_points=req.story_points or 1.0,
        estimated_hours=req.estimated_hours or 0.0,
        due_date=req.due_date
    )

    # Recalibrate analytics with new task
    _recalculate_analytics_with_cached_github(user["id"], team_id)

    return {
        "success": True,
        "message": f"Task '{task['task_key']}' created successfully.",
        "data": task
    }

@app.get("/api/v1/teams/{team_id}/tasks/{task_id}")
def get_task(team_id: str, task_id: str, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_access(team_id, user["id"])
    task = get_task_by_id(task_id)
    if not task or task.get("team_id") != team_id:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"data": task}

@app.put("/api/v1/teams/{team_id}/tasks/{task_id}")
def update_task_endpoint(
    team_id: str,
    task_id: str,
    req: UpdateTaskRequest,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    updated = update_task_db(
        task_id=task_id,
        team_id=team_id,
        title=req.title,
        description=req.description,
        assignee_id=req.assignee_id,
        priority=req.priority,
        status=req.status,
        story_points=req.story_points,
        estimated_hours=req.estimated_hours,
        due_date=req.due_date
    )
    if not updated:
        raise HTTPException(status_code=404, detail="Task not found")

    _recalculate_analytics_with_cached_github(user["id"], team_id)

    return {
        "success": True,
        "message": "Task updated successfully.",
        "data": updated
    }

@app.patch("/api/v1/teams/{team_id}/tasks/{task_id}/status")
def update_task_status_endpoint(
    team_id: str,
    task_id: str,
    req: UpdateTaskStatusRequest,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    updated = update_task_db(
        task_id=task_id,
        team_id=team_id,
        status=req.status
    )
    if not updated:
        raise HTTPException(status_code=404, detail="Task not found")

    _recalculate_analytics_with_cached_github(user["id"], team_id)

    return {
        "success": True,
        "message": f"Task status updated to {req.status}.",
        "data": updated
    }

@app.delete("/api/v1/teams/{team_id}/tasks/{task_id}")
def delete_task_endpoint(team_id: str, task_id: str, user: Dict[str, Any] = Depends(require_authenticated_user)):
    check_team_access(team_id, user["id"])
    deleted = delete_task_db(task_id, team_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Task not found")

    _recalculate_analytics_with_cached_github(user["id"], team_id)

    return {"success": True, "message": "Task deleted successfully."}

# ----------------- FEATURE 3 & 4: GitHub Integration -----------------

@app.post("/api/v1/teams/{team_id}/github")
def connect_github(
    team_id: str,
    req: ConnectRepoRequest,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_lead(team_id, user["id"])
    owner = req.repo_owner.strip()
    repo = req.repo_name.strip()
    token = req.github_token.strip() if req.github_token else None

    # Validate repository existence & accessibility via GitHub API
    is_valid, repo_meta, err_msg = validate_repository(owner=owner, repo=repo, token=token)
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=err_msg or f"Cannot access repository '{owner}/{repo}'. Please check the owner/name and token permissions."
        )

    default_branch = req.branch.strip() or repo_meta.get("default_branch", "main")

    # Save to SQLite
    saved = save_repository_config(
        user_id=user["id"],
        team_id=team_id,
        repo_owner=owner,
        repo_name=repo,
        branch=default_branch,
        github_token=token
    )

    # Trigger initial data synchronization
    try:
        _sync_repository_internal(user["id"], team_id)
        sync_msg = "Repository connected and initial data synchronized successfully."
    except Exception as e:
        sync_msg = f"Repository connected, but initial sync had a warning: {str(e)}"

    return {
        "success": True,
        "message": sync_msg,
        "repository": f"{owner}/{repo}",
        "default_branch": default_branch,
        "has_token": saved["has_token"]
    }

@app.get("/api/v1/teams/{team_id}/repo-info")
def get_repo_info(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    config = get_repository_config(user["id"], team_id)
    if not config:
        return {
            "configured": False,
            "team_id": team_id,
            "message": "No repository configured yet."
        }
    return {
        "configured": True,
        "data": config
    }

@app.post("/api/v1/teams/{team_id}/sync")
def trigger_sync(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    analytics = _sync_repository_internal(user["id"], team_id)
    return {
        "success": True,
        "message": "Data synchronization completed successfully",
        "timestamp": analytics.get("last_updated"),
        "records_processed": {
            "members": analytics["metrics"]["total_members"],
            "tasks": analytics["metrics"]["total_tasks"],
            "pull_requests": analytics["reviews_data"]["total_pull_requests"],
            "detected_risks": len(analytics["risks_ledger"])
        }
    }

@app.get("/api/v1/teams/{team_id}/sync-status")
def get_sync_status(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    config = get_repository_config(user["id"], team_id)
    analytics = get_latest_analytics(user["id"], team_id)

    if not config:
        return {
            "data": {
                "team_id": team_id,
                "repository": "Not Configured",
                "default_branch": "main",
                "connection_type": "GitHub REST API",
                "last_synced_at": None,
                "status": "not_configured",
                "sync_duration_seconds": 0.0,
                "records_processed": {"commits": 0, "pull_requests": 0, "reviews": 0, "tasks_imported": 0},
                "validation_errors": ["No repository connected. Configure a repository in the form above."]
            }
        }

    records = {
        "members": analytics["metrics"]["total_members"] if analytics else 0,
        "pull_requests": analytics["reviews_data"]["total_pull_requests"] if analytics else 0,
        "tasks": analytics["metrics"]["total_tasks"] if analytics else 0
    }

    return {
        "data": {
            "team_id": team_id,
            "repository": config["repository"],
            "default_branch": config["default_branch"],
            "connection_type": "GitHub REST API (Secure Backend)",
            "last_synced_at": config["last_synced_at"],
            "status": config["sync_status"],
            "sync_duration_seconds": 2.1,
            "records_processed": records,
            "validation_errors": [] if config["sync_status"] == "success" else [config.get("sync_message", "Sync error")]
        }
    }

# ----------------- FEATURE 5, 6, 7, 8, 9: Analytics Endpoints -----------------

def _get_or_sync_analytics(user_id: str, team_id: str) -> Dict[str, Any]:
    cached = get_latest_analytics(user_id, team_id)
    if cached:
        return cached

    # If repository is configured, sync it automatically
    config = get_repository_config(user_id, team_id)
    if config:
        return _sync_repository_internal(user_id, team_id)

    # If not configured, raise 404 with helpful setup instruction
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="No repository configured for this workspace. Please connect a repository in Data Sources to view dynamic analytics."
    )

@app.get("/api/v1/teams/{team_id}/dashboard")
def get_dashboard(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    analytics = _get_or_sync_analytics(user["id"], team_id)
    team = get_team_by_id(team_id)
    team_name = team["name"] if team else f"Workspace — {analytics['repository']}"

    return {
        "data": {
            "team_id": team_id,
            "team_name": team_name,
            "repository": analytics["repository"],
            "is_demo": False,
            "last_updated": analytics["last_updated"],
            "overall_risk_level": analytics["overall_risk_level"],
            "onboarding_checklist": analytics.get("onboarding_checklist"),
            "unmapped_contributors": analytics.get("unmapped_contributors", []),
            "metrics": analytics["metrics"],
            "workload_summary": analytics["workload_summary"],
            "review_participation_summary": analytics["review_participation_summary"],
            "integration_risk_indicators": analytics["integration_risk_indicators"],
            "recent_warnings": analytics["recent_warnings"]
        }
    }

@app.get("/api/v1/teams/{team_id}/workload")
def get_workload(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    analytics = _get_or_sync_analytics(user["id"], team_id)
    return {
        "data": {
            "team_id": team_id,
            **analytics["workload_data"]
        }
    }

@app.get("/api/v1/teams/{team_id}/reviews")
def get_reviews(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    analytics = _get_or_sync_analytics(user["id"], team_id)
    return {
        "data": {
            "team_id": team_id,
            **analytics["reviews_data"]
        }
    }

@app.get("/api/v1/teams/{team_id}/integration-risks")
def get_integration_risks(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    analytics = _get_or_sync_analytics(user["id"], team_id)
    return {
        "data": {
            "team_id": team_id,
            **analytics["integration_risks_data"]
        }
    }

@app.get("/api/v1/teams/{team_id}/risks")
def get_risks(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    analytics = _get_or_sync_analytics(user["id"], team_id)
    return {
        "data": analytics["risks_ledger"]
    }

@app.get("/api/v1/teams/{team_id}/recommendations")
def get_recommendations(
    team_id: str,
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    analytics = _get_or_sync_analytics(user["id"], team_id)
    return {
        "data": analytics["recent_warnings"]
    }

# ----------------- Task Ingestion (CSV) -----------------

@app.post("/api/v1/teams/{team_id}/tasks/import")
async def import_tasks(
    team_id: str,
    file: UploadFile = File(...),
    user: Dict[str, Any] = Depends(require_authenticated_user)
):
    check_team_access(team_id, user["id"])
    content = await file.read()
    decoded = content.decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(decoded))

    tasks_to_save = []
    for row in reader:
        norm_row = {k.strip().lower(): v.strip() for k, v in row.items() if k and v}
        t_id = norm_row.get("task_id") or norm_row.get("id") or norm_row.get("key") or f"TASK-{len(tasks_to_save)+1}"
        title = norm_row.get("title") or norm_row.get("summary") or norm_row.get("name") or "Untitled Task"
        assignee = norm_row.get("assignee_github_username") or norm_row.get("assignee") or norm_row.get("user") or ""
        pts_str = norm_row.get("story_points") or norm_row.get("points") or norm_row.get("estimate") or "1.0"
        try:
            pts = float(pts_str)
        except Exception:
            pts = 1.0
        status_val = norm_row.get("status") or "In Progress"
        due = norm_row.get("due_date") or norm_row.get("due") or ""

        tasks_to_save.append({
            "task_id": t_id,
            "title": title,
            "assignee_github_username": assignee.lower(),
            "story_points": pts,
            "status": status_val,
            "due_date": due
        })

    save_team_tasks(team_id, tasks_to_save)
    _recalculate_analytics_with_cached_github(user["id"], team_id)

    return {
        "success": True,
        "message": f"Successfully parsed and imported {len(tasks_to_save)} tasks from '{file.filename}'.",
        "rows_processed": len(tasks_to_save),
        "validation_warnings": 0
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
