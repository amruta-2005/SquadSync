"""
Database operations for SquadSync teams, memberships, invitations,
tasks, repositories, and sync snapshots.
Uses SQLite for persistence, tied to the user's authenticated session.
"""

import sqlite3
import json
import time
import uuid
import secrets
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple

DB_PATH = Path(__file__).parent / "squadsync_auth.db"

def init_extended_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # 1. Repositories Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS repositories (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            team_id TEXT NOT NULL,
            repo_owner TEXT NOT NULL,
            repo_name TEXT NOT NULL,
            default_branch TEXT NOT NULL DEFAULT 'main',
            github_token TEXT,
            last_synced_at TEXT,
            sync_status TEXT DEFAULT 'pending',
            sync_message TEXT,
            raw_data_json TEXT,
            analytics_json TEXT,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    # 2. Teams Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS teams (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            created_by TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    # 3. Team Memberships Table (includes role & GitHub username mapping)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS team_memberships (
            id TEXT PRIMARY KEY,
            team_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'developer',
            github_username TEXT DEFAULT '',
            joined_at INTEGER NOT NULL,
            FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE(team_id, user_id)
        )
    """)

    # 4. Team Invitations Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS team_invitations (
            id TEXT PRIMARY KEY,
            team_id TEXT NOT NULL,
            email TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'developer',
            status TEXT NOT NULL DEFAULT 'pending',
            invited_by TEXT NOT NULL,
            invitation_token TEXT UNIQUE NOT NULL,
            created_at INTEGER NOT NULL,
            expires_at INTEGER NOT NULL,
            responded_at INTEGER,
            FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
            FOREIGN KEY (invited_by) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    # 5. Database-Backed Tasks Table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            team_id TEXT NOT NULL,
            task_key TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            assignee_id TEXT DEFAULT '',
            assignee_name TEXT DEFAULT '',
            assignee_github_username TEXT DEFAULT '',
            priority TEXT NOT NULL DEFAULT 'Medium',
            status TEXT NOT NULL DEFAULT 'Todo',
            story_points REAL DEFAULT 1.0,
            estimated_hours REAL DEFAULT 0.0,
            due_date TEXT,
            created_by TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE
        )
    """)

    # 6. Legacy CSV Tasks Table (kept for backwards compatibility)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS team_tasks (
            id TEXT PRIMARY KEY,
            team_id TEXT NOT NULL,
            task_id TEXT NOT NULL,
            title TEXT NOT NULL,
            assignee_github_username TEXT,
            story_points REAL DEFAULT 1.0,
            status TEXT DEFAULT 'Pending',
            due_date TEXT,
            created_at INTEGER NOT NULL
        )
    """)

    conn.commit()

    # Seed default team-alpha if not existing
    cursor.execute("SELECT id FROM teams WHERE id = 'team-alpha'")
    if not cursor.fetchone():
        now = int(time.time())
        cursor.execute("""
            INSERT INTO teams (id, name, description, created_by, created_at, updated_at)
            VALUES ('team-alpha', 'Team Alpha — DevPulse', 'Senior Capstone Project', 'usr-alex-chen', ?, ?)
        """, (now, now))

        # Add Alex Chen and Maya Patel to team-alpha if they exist in users
        cursor.execute("SELECT id FROM users WHERE id = 'usr-alex-chen'")
        if cursor.fetchone():
            cursor.execute("""
                INSERT OR IGNORE INTO team_memberships (id, team_id, user_id, role, github_username, joined_at)
                VALUES ('tm-alpha-alex', 'team-alpha', 'usr-alex-chen', 'team_lead', 'alexchen', ?)
            """, (now,))

        cursor.execute("SELECT id FROM users WHERE id = 'usr-maya-patel'")
        if cursor.fetchone():
            cursor.execute("""
                INSERT OR IGNORE INTO team_memberships (id, team_id, user_id, role, github_username, joined_at)
                VALUES ('tm-alpha-maya', 'team-alpha', 'usr-maya-patel', 'developer', 'mayapatel', ?)
            """, (now,))

        conn.commit()

    conn.close()

# -------------------------------------------------------------
# Teams & Memberships Management
# -------------------------------------------------------------

def create_team(user_id: str, name: str, description: str = "") -> Dict[str, Any]:
    now = int(time.time())
    team_id = f"team-{uuid.uuid4().hex[:8]}"

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO teams (id, name, description, created_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (team_id, name.strip(), description.strip(), user_id, now, now))

    # Add creator as team_lead
    membership_id = f"tm-{team_id}-{user_id}"
    cursor.execute("""
        INSERT INTO team_memberships (id, team_id, user_id, role, github_username, joined_at)
        VALUES (?, ?, ?, 'team_lead', '', ?)
    """, (membership_id, team_id, user_id, now))

    conn.commit()
    conn.close()

    return {
        "id": team_id,
        "name": name.strip(),
        "description": description.strip(),
        "created_by": user_id,
        "created_at": now,
        "updated_at": now,
        "role": "team_lead"
    }

def update_team(team_id: str, name: str, description: Optional[str] = None) -> Optional[Dict[str, Any]]:
    now = int(time.time())
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if description is not None:
        cursor.execute("""
            UPDATE teams SET name = ?, description = ?, updated_at = ? WHERE id = ?
        """, (name.strip(), description.strip(), now, team_id))
    else:
        cursor.execute("""
            UPDATE teams SET name = ?, updated_at = ? WHERE id = ?
        """, (name.strip(), now, team_id))

    conn.commit()

    cursor.execute("SELECT * FROM teams WHERE id = ?", (team_id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return None
    return dict(row)

def get_team_by_id(team_id: str) -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM teams WHERE id = ?", (team_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    return dict(row)

def get_user_teams(user_id: str) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # Query all teams where user is a member
    cursor.execute("""
        SELECT t.id, t.name, t.description, t.created_by, t.created_at, t.updated_at,
               tm.role, tm.github_username,
               r.repo_owner, r.repo_name, r.default_branch, r.last_synced_at, r.sync_status
        FROM team_memberships tm
        JOIN teams t ON tm.team_id = t.id
        LEFT JOIN repositories r ON r.team_id = t.id
        WHERE tm.user_id = ?
        ORDER BY t.created_at DESC
    """, (user_id,))
    rows = cursor.fetchall()

    teams_list = []
    for r in rows:
        t_id = r["id"]
        # Count members
        cursor.execute("SELECT COUNT(*) FROM team_memberships WHERE team_id = ?", (t_id,))
        m_count = cursor.fetchone()[0]

        is_repo_configured = bool(r["repo_owner"] and r["repo_name"])
        repo_display = f"{r['repo_owner']}/{r['repo_name']}" if is_repo_configured else "No Repository Connected"

        teams_list.append({
            "id": t_id,
            "name": r["name"],
            "description": r["description"],
            "repo_name": repo_display,
            "user_role": r["role"],
            "my_github_username": r["github_username"] or "",
            "is_configured": is_repo_configured,
            "last_synced_at": r["last_synced_at"],
            "sync_status": r["sync_status"] or "not_configured",
            "members_count": m_count
        })

    conn.close()
    return teams_list

def get_team_members(team_id: str) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
        SELECT u.id as user_id, u.name, u.email, u.avatar_url,
               tm.role, tm.github_username, tm.joined_at
        FROM team_memberships tm
        JOIN users u ON tm.user_id = u.id
        WHERE tm.team_id = ?
        ORDER BY tm.joined_at ASC
    """, (team_id,))
    rows = cursor.fetchall()
    conn.close()

    return [
        {
            "id": r["user_id"],
            "user_id": r["user_id"],
            "name": r["name"],
            "email": r["email"],
            "avatar_url": r["avatar_url"],
            "role": r["role"],
            "github_username": r["github_username"] or "",
            "joined_at": r["joined_at"]
        }
        for r in rows
    ]

def get_team_membership(team_id: str, user_id: str) -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM team_memberships WHERE team_id = ? AND user_id = ?
    """, (team_id, user_id))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    return dict(row)

def update_member_role(team_id: str, user_id: str, new_role: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE team_memberships SET role = ? WHERE team_id = ? AND user_id = ?
    """, (new_role, team_id, user_id))
    conn.commit()
    conn.close()

def update_member_github_username(team_id: str, user_id: str, github_username: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE team_memberships SET github_username = ? WHERE team_id = ? AND user_id = ?
    """, (github_username.strip().lstrip("@"), team_id, user_id))
    conn.commit()
    conn.close()

def remove_team_member(team_id: str, user_id: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        DELETE FROM team_memberships WHERE team_id = ? AND user_id = ?
    """, (team_id, user_id))
    conn.commit()
    conn.close()

# -------------------------------------------------------------
# Invitations Management
# -------------------------------------------------------------

def create_team_invitation(team_id: str, invited_by: str, email: str, role: str = "developer") -> Dict[str, Any]:
    now = int(time.time())
    expires_at = now + (7 * 86400) # 7 days validity
    invitation_id = f"inv-{uuid.uuid4().hex[:10]}"
    token = secrets.token_urlsafe(24)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO team_invitations (id, team_id, email, role, status, invited_by, invitation_token, created_at, expires_at)
        VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?)
    """, (invitation_id, team_id, email.strip().lower(), role, invited_by, token, now, expires_at))

    conn.commit()
    conn.close()

    return {
        "id": invitation_id,
        "team_id": team_id,
        "email": email.strip().lower(),
        "role": role,
        "status": "pending",
        "invitation_token": token,
        "created_at": now,
        "expires_at": expires_at
    }

def get_team_invitations(team_id: str) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
        SELECT ti.*, u.name as inviter_name, u.email as inviter_email
        FROM team_invitations ti
        JOIN users u ON ti.invited_by = u.id
        WHERE ti.team_id = ?
        ORDER BY ti.created_at DESC
    """, (team_id,))
    rows = cursor.fetchall()
    conn.close()

    return [dict(r) for r in rows]

def get_user_pending_invitations(email: str) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("""
        SELECT ti.*, t.name as team_name, t.description as team_description, u.name as inviter_name
        FROM team_invitations ti
        JOIN teams t ON ti.team_id = t.id
        JOIN users u ON ti.invited_by = u.id
        WHERE lower(ti.email) = ? AND ti.status = 'pending'
        ORDER BY ti.created_at DESC
    """, (email.strip().lower(),))
    rows = cursor.fetchall()
    conn.close()

    return [dict(r) for r in rows]

def respond_to_invitation(invitation_id: str, user_id: str, user_email: str, action: str) -> Dict[str, Any]:
    now = int(time.time())
    action_clean = action.strip().lower() # 'accept' or 'decline'

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM team_invitations WHERE id = ?", (invitation_id,))
    inv = cursor.fetchone()

    if not inv:
        conn.close()
        raise ValueError("Invitation not found.")

    if inv["status"] != "pending":
        conn.close()
        raise ValueError(f"Invitation has already been {inv['status']}.")

    if inv["email"].lower() != user_email.strip().lower():
        conn.close()
        raise ValueError("This invitation was sent to a different email address.")

    new_status = "accepted" if action_clean == "accept" else "declined"
    cursor.execute("""
        UPDATE team_invitations SET status = ?, responded_at = ? WHERE id = ?
    """, (new_status, now, invitation_id))

    if action_clean == "accept":
        # Add to team_memberships
        m_id = f"tm-{inv['team_id']}-{user_id}"
        cursor.execute("""
            INSERT OR IGNORE INTO team_memberships (id, team_id, user_id, role, github_username, joined_at)
            VALUES (?, ?, ?, ?, '', ?)
        """, (m_id, inv["team_id"], user_id, inv["role"], now))

    conn.commit()
    conn.close()

    return {
        "invitation_id": invitation_id,
        "team_id": inv["team_id"],
        "status": new_status,
        "message": f"Invitation successfully {new_status}."
    }

# -------------------------------------------------------------
# Database-Backed Task Management
# -------------------------------------------------------------

def create_task(
    team_id: str,
    created_by: str,
    title: str,
    description: str = "",
    assignee_id: Optional[str] = None,
    priority: str = "Medium",
    status: str = "Todo",
    story_points: float = 1.0,
    estimated_hours: float = 0.0,
    due_date: Optional[str] = None
) -> Dict[str, Any]:
    now = int(time.time())
    task_id = f"task-{uuid.uuid4().hex[:10]}"

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # Calculate task_key (e.g. TASK-1, TASK-2)
    cursor.execute("SELECT COUNT(*) FROM tasks WHERE team_id = ?", (team_id,))
    existing_count = cursor.fetchone()[0]
    task_key = f"TASK-{existing_count + 1}"

    # Lookup assignee details if assignee_id provided
    assignee_name = ""
    assignee_github_username = ""
    if assignee_id:
        cursor.execute("SELECT name FROM users WHERE id = ?", (assignee_id,))
        u = cursor.fetchone()
        if u:
            assignee_name = u["name"]
        cursor.execute("SELECT github_username FROM team_memberships WHERE team_id = ? AND user_id = ?", (team_id, assignee_id))
        tm = cursor.fetchone()
        if tm and tm["github_username"]:
            assignee_github_username = tm["github_username"]

    cursor.execute("""
        INSERT INTO tasks (
            id, team_id, task_key, title, description, assignee_id, assignee_name,
            assignee_github_username, priority, status, story_points, estimated_hours,
            due_date, created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        task_id, team_id, task_key, title.strip(), description.strip(),
        assignee_id or "", assignee_name, assignee_github_username,
        priority, status, float(story_points or 1.0), float(estimated_hours or 0.0),
        due_date or None, created_by, now, now
    ))

    conn.commit()
    conn.close()

    return {
        "id": task_id,
        "team_id": team_id,
        "task_key": task_key,
        "title": title.strip(),
        "description": description.strip(),
        "assignee_id": assignee_id or "",
        "assignee_name": assignee_name,
        "assignee_github_username": assignee_github_username,
        "priority": priority,
        "status": status,
        "story_points": float(story_points or 1.0),
        "estimated_hours": float(estimated_hours or 0.0),
        "due_date": due_date,
        "created_by": created_by,
        "created_at": now,
        "updated_at": now
    }

def get_team_tasks_db(
    team_id: str,
    status: Optional[str] = None,
    priority: Optional[str] = None,
    assignee_id: Optional[str] = None
) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    query = "SELECT * FROM tasks WHERE team_id = ?"
    params: List[Any] = [team_id]

    if status and status.upper() != "ALL":
        query += " AND status = ?"
        params.append(status)

    if priority and priority.upper() != "ALL":
        query += " AND priority = ?"
        params.append(priority)

    if assignee_id and assignee_id.upper() != "ALL":
        query += " AND assignee_id = ?"
        params.append(assignee_id)

    query += " ORDER BY created_at DESC"
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    tasks_list = []
    for r in rows:
        d = dict(r)
        # Check overdue status
        is_completed = d["status"].lower() in ["completed", "done", "closed"]
        overdue = False
        if d.get("due_date") and not is_completed:
            try:
                # Simple date check
                due_str = d["due_date"].split("T")[0]
                today_str = time.strftime("%Y-%m-%d", time.gmtime())
                if due_str < today_str:
                    overdue = True
            except Exception:
                pass
        d["overdue"] = overdue
        tasks_list.append(d)

    return tasks_list

def get_task_by_id(task_id: str) -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    return dict(row)

def update_task_db(
    task_id: str,
    team_id: str,
    title: Optional[str] = None,
    description: Optional[str] = None,
    assignee_id: Optional[str] = None,
    priority: Optional[str] = None,
    status: Optional[str] = None,
    story_points: Optional[float] = None,
    estimated_hours: Optional[float] = None,
    due_date: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    now = int(time.time())
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM tasks WHERE id = ? AND team_id = ?", (task_id, team_id))
    existing = cursor.fetchone()
    if not existing:
        conn.close()
        return None

    new_title = title.strip() if title is not None else existing["title"]
    new_desc = description.strip() if description is not None else existing["description"]
    new_pri = priority if priority is not None else existing["priority"]
    new_status = status if status is not None else existing["status"]
    new_pts = float(story_points) if story_points is not None else existing["story_points"]
    new_hrs = float(estimated_hours) if estimated_hours is not None else existing["estimated_hours"]
    new_due = due_date if due_date is not None else existing["due_date"]

    new_assignee_id = assignee_id if assignee_id is not None else existing["assignee_id"]
    new_assignee_name = existing["assignee_name"]
    new_assignee_gh = existing["assignee_github_username"]

    if assignee_id is not None:
        if assignee_id:
            cursor.execute("SELECT name FROM users WHERE id = ?", (assignee_id,))
            u = cursor.fetchone()
            new_assignee_name = u["name"] if u else ""
            cursor.execute("SELECT github_username FROM team_memberships WHERE team_id = ? AND user_id = ?", (team_id, assignee_id))
            tm = cursor.fetchone()
            new_assignee_gh = tm["github_username"] if (tm and tm["github_username"]) else ""
        else:
            new_assignee_name = ""
            new_assignee_gh = ""

    cursor.execute("""
        UPDATE tasks SET
            title = ?, description = ?, assignee_id = ?, assignee_name = ?,
            assignee_github_username = ?, priority = ?, status = ?,
            story_points = ?, estimated_hours = ?, due_date = ?, updated_at = ?
        WHERE id = ? AND team_id = ?
    """, (
        new_title, new_desc, new_assignee_id, new_assignee_name,
        new_assignee_gh, new_pri, new_status, new_pts, new_hrs,
        new_due, now, task_id, team_id
    ))

    conn.commit()
    cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
    updated = cursor.fetchone()
    conn.close()

    return dict(updated) if updated else None

def delete_task_db(task_id: str, team_id: str) -> bool:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM tasks WHERE id = ? AND team_id = ?", (task_id, team_id))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted

# -------------------------------------------------------------
# Repositories & Sync Snapshots
# -------------------------------------------------------------

def save_repository_config(
    user_id: str,
    team_id: str,
    repo_owner: str,
    repo_name: str,
    branch: str = "main",
    github_token: Optional[str] = None
) -> Dict[str, Any]:
    now = int(time.time())
    repo_id = f"repo-{team_id}"

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Check if exists
    cursor.execute("SELECT github_token FROM repositories WHERE team_id = ?", (team_id,))
    existing = cursor.fetchone()

    token_to_store = github_token
    if not token_to_store and existing and existing[0]:
        token_to_store = existing[0]

    cursor.execute("""
        INSERT INTO repositories (
            id, user_id, team_id, repo_owner, repo_name, default_branch,
            github_token, last_synced_at, sync_status, sync_message,
            created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            user_id = excluded.user_id,
            repo_owner = excluded.repo_owner,
            repo_name = excluded.repo_name,
            default_branch = excluded.default_branch,
            github_token = excluded.github_token,
            updated_at = excluded.updated_at
    """, (
        repo_id, user_id, team_id, repo_owner.strip(), repo_name.strip(), branch.strip() or "main",
        token_to_store.strip() if token_to_store else None, None, "configured",
        "Repository configured. Ready to synchronize.", now, now
    ))

    conn.commit()
    conn.close()

    return {
        "team_id": team_id,
        "repo_owner": repo_owner.strip(),
        "repo_name": repo_name.strip(),
        "repository": f"{repo_owner.strip()}/{repo_name.strip()}",
        "default_branch": branch.strip() or "main",
        "has_token": bool(token_to_store)
    }

def get_repository_config(user_id: str, team_id: str) -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM repositories WHERE team_id = ?", (team_id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return None

    return {
        "team_id": row["team_id"],
        "repo_owner": row["repo_owner"],
        "repo_name": row["repo_name"],
        "repository": f"{row['repo_owner']}/{row['repo_name']}",
        "default_branch": row["default_branch"],
        "last_synced_at": row["last_synced_at"],
        "sync_status": row["sync_status"],
        "sync_message": row["sync_message"],
        "has_token": bool(row["github_token"]),
        "has_analytics": bool(row["analytics_json"])
    }

def get_internal_repo_credentials(user_id: str, team_id: str) -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM repositories WHERE team_id = ?", (team_id,))
    row = cursor.fetchone()
    conn.close()

    if not row:
        return None

    return {
        "repo_owner": row["repo_owner"],
        "repo_name": row["repo_name"],
        "default_branch": row["default_branch"],
        "github_token": row["github_token"]
    }

def update_repository_sync_snapshot(
    user_id: str,
    team_id: str,
    raw_data: Dict[str, Any],
    analytics_data: Dict[str, Any],
    sync_status: str = "success",
    sync_message: str = "Synchronized successfully"
):
    now = int(time.time())
    iso_now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE repositories
        SET last_synced_at = ?,
            sync_status = ?,
            sync_message = ?,
            raw_data_json = ?,
            analytics_json = ?,
            updated_at = ?
        WHERE team_id = ?
    """, (
        iso_now, sync_status, sync_message,
        json.dumps(raw_data), json.dumps(analytics_data), now,
        team_id
    ))
    conn.commit()
    conn.close()

def get_latest_analytics(user_id: str, team_id: str) -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT analytics_json, last_synced_at, repo_owner, repo_name FROM repositories WHERE team_id = ?",
        (team_id,)
    )
    row = cursor.fetchone()
    conn.close()

    if not row or not row["analytics_json"]:
        return None

    try:
        data = json.loads(row["analytics_json"])
        data["last_updated"] = row["last_synced_at"] or data.get("last_updated")
        return data
    except Exception:
        return None

def save_team_tasks(team_id: str, tasks: List[Dict[str, Any]]):
    """Bridge for CSV tasks import into database tasks table."""
    now = int(time.time())
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    for idx, t in enumerate(tasks):
        raw_key = str(t.get("task_id") or t.get("task_key") or f"CSV-{now}-{idx}")
        task_id = f"task-{team_id}-{raw_key}"
        task_key = raw_key
        cursor.execute("""
            INSERT INTO tasks (
                id, team_id, task_key, title, description, assignee_id, assignee_name,
                assignee_github_username, priority, status, story_points, estimated_hours,
                due_date, created_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, '', '', '', ?, 'Medium', ?, ?, 0.0, ?, 'csv_importer', ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                team_id = excluded.team_id,
                title = excluded.title,
                assignee_github_username = excluded.assignee_github_username,
                story_points = excluded.story_points,
                status = excluded.status,
                due_date = excluded.due_date,
                updated_at = excluded.updated_at
        """, (
            task_id, team_id, task_key, t.get("title", "Imported Task"),
            t.get("assignee_github_username", "").lower(),
            t.get("status", "In Progress"),
            float(t.get("story_points", 1.0) or 1.0),
            t.get("due_date"),
            now, now
        ))

    conn.commit()
    conn.close()

def get_team_tasks(team_id: str) -> List[Dict[str, Any]]:
    return get_team_tasks_db(team_id)

# Initialize schema on module load
init_extended_db()
