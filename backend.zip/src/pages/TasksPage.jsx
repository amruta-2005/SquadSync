import React, { useState, useEffect, useCallback } from 'react';
import {
  CheckSquare,
  Plus,
  Filter,
  Search,
  Calendar,
  Clock,
  User,
  AlertTriangle,
  Award,
  Trash2,
  Edit2,
  Kanban,
  List,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../auth/AuthProvider';
import apiService from '../services/api';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import Button from '../components/common/Button';
import LoadingSkeleton from '../components/common/LoadingSkeleton';
import EmptyState from '../components/common/EmptyState';
import CreateTaskModal from '../components/tasks/CreateTaskModal';
import { formatDate } from '../utils/formatters';

export default function TasksPage() {
  const { selectedTeam, selectedTeamId, isDemoMode, addToast } = useApp();
  const { user } = useAuth();

  const [tasks, setTasks] = useState([]);
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [assigneeFilter, setAssigneeFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('board'); // 'board' | 'list'
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isUploadingCsv, setIsUploadingCsv] = useState(false);

  // Load tasks and team members from backend
  const loadData = useCallback(async () => {
    if (!selectedTeamId) return;
    setLoading(true);
    try {
      const [tasksRes, membersRes] = await Promise.all([
        apiService.getTasks(selectedTeamId, {
          status: statusFilter,
          priority: priorityFilter,
          assignee_id: assigneeFilter
        }),
        apiService.getTeamMembers(selectedTeamId).catch(() => ({ data: [] }))
      ]);

      setTasks(tasksRes.data || []);
      setMembers(membersRes.data || []);
    } catch (err) {
      addToast(`Error loading tasks: ${err.message}`, 'error');
    } finally {
      setLoading(false);
    }
  }, [selectedTeamId, statusFilter, priorityFilter, assigneeFilter, addToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleStatusChange = async (taskId, newStatus) => {
    try {
      await apiService.updateTaskStatus(selectedTeamId, taskId, newStatus);
      addToast(`Task moved to ${newStatus}`, 'success');
      loadData();
    } catch (err) {
      addToast(`Failed to update status: ${err.message}`, 'error');
    }
  };

  const handleDeleteTask = async (taskId, taskTitle) => {
    if (!window.confirm(`Are you sure you want to delete task "${taskTitle}"?`)) return;
    try {
      await apiService.deleteTask(selectedTeamId, taskId);
      addToast('Task deleted successfully', 'info');
      loadData();
    } catch (err) {
      addToast(`Failed to delete task: ${err.message}`, 'error');
    }
  };

  const handleCsvImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingCsv(true);
    try {
      const res = await apiService.importTasksCsv(selectedTeamId, file, isDemoMode);
      addToast(res.message || `Imported tasks from ${file.name}!`, 'success');
      loadData();
    } catch (err) {
      addToast(`Import failed: ${err.message}`, 'error');
    } finally {
      setIsUploadingCsv(false);
      e.target.value = '';
    }
  };

  // Filter tasks locally by search query
  const filteredTasks = tasks.filter(task => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      task.title?.toLowerCase().includes(q) ||
      task.task_key?.toLowerCase().includes(q) ||
      task.assignee_name?.toLowerCase().includes(q) ||
      task.assignee_github_username?.toLowerCase().includes(q)
    );
  });

  // Calculate summary metrics
  const totalTasks = tasks.length;
  const inProgressTasks = tasks.filter(t => t.status === 'In Progress').length;
  const completedTasks = tasks.filter(t => t.status === 'Completed').length;
  const overdueTasks = tasks.filter(t => t.overdue).length;
  const totalPoints = tasks.reduce((sum, t) => sum + (parseFloat(t.story_points) || 0), 0);

  const getPriorityBadgeVariant = (priority) => {
    switch (priority) {
      case 'High': return 'rose';
      case 'Medium': return 'amber';
      case 'Low': return 'slate';
      default: return 'slate';
    }
  };

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case 'Completed': return 'emerald';
      case 'In Progress': return 'indigo';
      case 'Review': return 'purple';
      case 'Todo': return 'slate';
      default: return 'slate';
    }
  };

  const columns = ['Todo', 'In Progress', 'Review', 'Completed'];

  return (
    <div className="space-y-6">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Team Tasks & Backlog</h1>
            <Badge variant="purple">Database Backed</Badge>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Managing tasks for <span className="font-medium text-slate-800">{selectedTeam?.name || 'Current Team'}</span> • Correlated with GitHub PRs & Commits
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* CSV Import */}
          <label className="cursor-pointer">
            <input
              type="file"
              accept=".csv"
              onChange={handleCsvImport}
              className="hidden"
              disabled={isUploadingCsv}
            />
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-xs transition-colors">
              <Upload className="w-3.5 h-3.5 text-slate-500" />
              {isUploadingCsv ? 'Importing...' : 'Import CSV'}
            </span>
          </label>

          <Button
            size="sm"
            variant="secondary"
            icon={RefreshCw}
            onClick={loadData}
            title="Refresh tasks from SQLite"
          >
            Refresh
          </Button>

          <Button
            size="sm"
            variant="primary"
            icon={Plus}
            onClick={() => setIsCreateModalOpen(true)}
          >
            Create Task
          </Button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Tasks</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{totalTasks}</p>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-indigo-600 uppercase tracking-wider">In Progress</p>
          <p className="text-xl font-bold text-indigo-700 mt-1">{inProgressTasks}</p>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-emerald-600 uppercase tracking-wider">Completed</p>
          <p className="text-xl font-bold text-emerald-700 mt-1">{completedTasks}</p>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-[11px] font-semibold text-rose-600 uppercase tracking-wider">Overdue Tasks</p>
          <p className="text-xl font-bold text-rose-700 mt-1 flex items-center gap-1.5">
            {overdueTasks}
            {overdueTasks > 0 && <AlertTriangle className="w-4 h-4 text-rose-500" />}
          </p>
        </div>
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs col-span-2 sm:col-span-1">
          <p className="text-[11px] font-semibold text-purple-600 uppercase tracking-wider">Story Points</p>
          <p className="text-xl font-bold text-purple-700 mt-1">{totalPoints} pts</p>
        </div>
      </div>

      {/* Filters & View Mode Bar */}
      <Card className="p-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            {/* Search */}
            <div className="relative min-w-[200px] flex-1 sm:flex-initial">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search title, key, assignee..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:bg-white"
              />
            </div>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-slate-700"
            >
              <option value="All">All Statuses</option>
              <option value="Todo">Todo</option>
              <option value="In Progress">In Progress</option>
              <option value="Review">Review</option>
              <option value="Completed">Completed</option>
            </select>

            {/* Priority Filter */}
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-slate-700"
            >
              <option value="All">All Priorities</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>

            {/* Assignee Filter */}
            <select
              value={assigneeFilter}
              onChange={(e) => setAssigneeFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 text-slate-700"
            >
              <option value="All">All Assignees</option>
              {members.map(m => (
                <option key={m.user_id} value={m.user_id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          {/* Board / List View Switcher */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg self-end md:self-auto">
            <button
              onClick={() => setViewMode('board')}
              className={`p-1.5 rounded text-xs font-medium flex items-center gap-1.5 transition-colors ${
                viewMode === 'board' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Kanban className="w-3.5 h-3.5" />
              <span>Board</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded text-xs font-medium flex items-center gap-1.5 transition-colors ${
                viewMode === 'list' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List</span>
            </button>
          </div>
        </div>
      </Card>

      {/* Main Content Area */}
      {loading ? (
        <LoadingSkeleton type="cards" count={3} />
      ) : filteredTasks.length === 0 ? (
        <EmptyState
          title="No tasks found"
          description={
            tasks.length === 0
              ? 'Get started by creating your first team task or importing a task board CSV.'
              : 'No tasks match your current filter criteria.'
          }
          actionLabel="Create Task"
          onAction={() => setIsCreateModalOpen(true)}
        />
      ) : viewMode === 'board' ? (
        /* Kanban Board View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start">
          {columns.map((colStatus) => {
            const colTasks = filteredTasks.filter(t => t.status === colStatus);
            return (
              <div key={colStatus} className="bg-slate-50/70 rounded-xl p-3 border border-slate-200">
                <div className="flex items-center justify-between mb-3 px-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                      {colStatus}
                    </span>
                    <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center justify-center">
                      {colTasks.length}
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  {colTasks.map((task) => (
                    <div
                      key={task.id}
                      className="bg-white rounded-xl p-3.5 border border-slate-200/90 shadow-xs hover:border-purple-300 transition-all space-y-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] font-mono font-bold text-purple-700">
                          {task.task_key}
                        </span>
                        <div className="flex items-center gap-1">
                          <Badge variant={getPriorityBadgeVariant(task.priority)} size="sm">
                            {task.priority}
                          </Badge>
                          <button
                            onClick={() => handleDeleteTask(task.id, task.title)}
                            className="text-slate-400 hover:text-rose-600 p-0.5 rounded transition-colors"
                            title="Delete task"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <h4 className="text-xs font-bold text-slate-900 leading-snug">
                        {task.title}
                      </h4>

                      {task.description && (
                        <p className="text-[11px] text-slate-500 line-clamp-2">
                          {task.description}
                        </p>
                      )}

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
                        <div className="flex items-center gap-1.5 truncate max-w-[140px]">
                          <User className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate">
                            {task.assignee_name || (task.assignee_github_username ? `@${task.assignee_github_username}` : 'Unassigned')}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-purple-700 font-semibold">
                          <Award className="w-3 h-3" />
                          <span>{task.story_points} pt</span>
                        </div>
                      </div>

                      {task.due_date && (
                        <div className={`flex items-center gap-1 text-[10px] font-medium ${
                          task.overdue ? 'text-rose-600 font-bold' : 'text-slate-400'
                        }`}>
                          <Calendar className="w-3 h-3" />
                          <span>Due {formatDate(task.due_date)}</span>
                          {task.overdue && <span>(Overdue)</span>}
                        </div>
                      )}

                      {/* Quick Status Transition Dropdown */}
                      <div className="pt-1">
                        <select
                          value={task.status}
                          onChange={(e) => handleStatusChange(task.id, e.target.value)}
                          className="w-full text-[11px] font-semibold py-1 px-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md text-slate-700 focus:outline-none"
                        >
                          <option value="Todo">Move to: Todo</option>
                          <option value="In Progress">Move to: In Progress</option>
                          <option value="Review">Move to: Review</option>
                          <option value="Completed">Move to: Completed</option>
                        </select>
                      </div>
                    </div>
                  ))}

                  {colTasks.length === 0 && (
                    <div className="py-6 text-center text-slate-400 text-xs italic">
                      No tasks in this lane
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List / Table View */
        <Card className="overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Key</th>
                  <th className="py-3 px-4">Title</th>
                  <th className="py-3 px-4">Assignee</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Points</th>
                  <th className="py-3 px-4">Due Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTasks.map((task) => (
                  <tr key={task.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-purple-700 whitespace-nowrap">
                      {task.task_key}
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-900 max-w-xs truncate">
                      {task.title}
                    </td>
                    <td className="py-3 px-4 text-slate-700 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>
                          {task.assignee_name || (task.assignee_github_username ? `@${task.assignee_github_username}` : 'Unassigned')}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <Badge variant={getPriorityBadgeVariant(task.priority)} size="sm">
                        {task.priority}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <select
                        value={task.status}
                        onChange={(e) => handleStatusChange(task.id, e.target.value)}
                        className="text-xs font-semibold py-1 px-2 bg-slate-50 border border-slate-200 rounded-md text-slate-800"
                      >
                        <option value="Todo">Todo</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Review">Review</option>
                        <option value="Completed">Completed</option>
                      </select>
                    </td>
                    <td className="py-3 px-4 font-bold text-purple-700 whitespace-nowrap">
                      {task.story_points} pt
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap text-slate-600">
                      {task.due_date ? (
                        <span className={task.overdue ? 'text-rose-600 font-bold' : ''}>
                          {formatDate(task.due_date)} {task.overdue && '⚠️'}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={() => handleDeleteTask(task.id, task.title)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded transition-colors"
                        title="Delete task"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Create Task Modal */}
      <CreateTaskModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        teamId={selectedTeamId}
        members={members}
        onTaskCreated={() => loadData()}
      />
    </div>
  );
}
