import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import apiService from '../services/api';
import { DEMO_TEAMS } from '../services/demoData';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [teams, setTeams] = useState([
    {
      id: 'team-alpha',
      name: 'Workspace — Repository',
      repo_name: 'No Repository Connected',
      academic_term: 'Active Project',
      is_configured: false,
      members_count: 0
    }
  ]);
  const [selectedTeamId, setSelectedTeamId] = useState('team-alpha');
  const [backendStatus, setBackendStatus] = useState('checking'); // 'checking' | 'online' | 'offline'
  const [isDemoMode, setIsDemoMode] = useState(false); // Default to live mode!
  const [toasts, setToasts] = useState([]);

  const addToast = useCallback((message, type = 'info', duration = 4000) => {
    const id = Date.now() + Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    if (duration > 0) {
      setTimeout(() => {
        setToasts(prev => prev.filter(t => t.id !== id));
      }, duration);
    }
    return id;
  }, []);

  const removeToast = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const refreshTeams = useCallback(async () => {
    try {
      const res = await apiService.getTeams(false);
      if (res && res.data && res.data.length > 0) {
        setTeams(res.data);
        if (!res.data.find(t => t.id === selectedTeamId)) {
          setSelectedTeamId(res.data[0].id);
        }
      }
    } catch {
      // keep existing
    }
  }, [selectedTeamId]);

  const checkBackendHealth = useCallback(async () => {
    setBackendStatus('checking');
    try {
      await apiService.getHealth();
      setBackendStatus('online');
      await refreshTeams();
    } catch {
      setBackendStatus('offline');
    }
  }, [refreshTeams]);

  useEffect(() => {
    checkBackendHealth();
  }, [checkBackendHealth]);

  useEffect(() => {
    if (isDemoMode) {
      setTeams(DEMO_TEAMS);
    } else {
      refreshTeams();
    }
  }, [isDemoMode, refreshTeams]);

  const selectedTeam = teams.find(t => t.id === selectedTeamId) || teams[0] || {
    id: 'team-alpha',
    name: 'Workspace — Repository',
    repo_name: 'No Repository Connected'
  };

  const value = {
    teams,
    selectedTeamId,
    selectedTeam,
    setSelectedTeamId,
    backendStatus,
    isDemoMode,
    setIsDemoMode,
    apiBaseUrl: apiService.getBaseUrl(),
    checkBackendHealth,
    refreshTeams,
    toasts,
    addToast,
    removeToast
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
