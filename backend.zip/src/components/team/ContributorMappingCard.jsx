import React, { useState, useEffect, useCallback } from 'react';
import {
  Users,
  Github,
  UserPlus,
  Shield,
  Trash2,
  Check,
  AlertCircle,
  Mail,
  Clock,
  Save,
  CheckCircle2
} from 'lucide-react';
import Card from '../common/Card';
import Badge from '../common/Badge';
import Button from '../common/Button';
import InviteMemberModal from './InviteMemberModal';
import apiService from '../../services/api';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../auth/AuthProvider';
import { formatDate } from '../../utils/formatters';

export default function ContributorMappingCard({ teamId, onDataChanged }) {
  const { addToast } = useApp();
  const { user } = useAuth();

  const [members, setMembers] = useState([]);
  const [invitations, setInvitations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [editingGh, setEditingGh] = useState({});
  const [savingGh, setSavingGh] = useState({});

  const loadTeamData = useCallback(async () => {
    if (!teamId) return;
    setLoading(true);
    try {
      const [membersRes, invRes] = await Promise.all([
        apiService.getTeamMembers(teamId).catch(() => ({ data: [] })),
        apiService.getTeamInvitations(teamId).catch(() => ({ data: [] }))
      ]);

      const mList = membersRes.data || [];
      setMembers(mList);
      setInvitations(invRes.data || []);

      // initialize edit state
      const ghMap = {};
      mList.forEach(m => {
        ghMap[m.user_id] = m.github_username || '';
      });
      setEditingGh(ghMap);
    } catch (err) {
      addToast(`Error loading team members: ${err.message}`, 'error');
    } finally {
      setLoading(false);
    }
  }, [teamId, addToast]);

  useEffect(() => {
    loadTeamData();
  }, [loadTeamData]);

  const handleSaveGithub = async (userId) => {
    const ghVal = editingGh[userId] || '';
    setSavingGh(prev => ({ ...prev, [userId]: true }));
    try {
      await apiService.mapMemberGithub(teamId, userId, ghVal);
      addToast(`Mapped user to GitHub @${ghVal || 'None'}!`, 'success');
      loadTeamData();
      if (onDataChanged) onDataChanged();
    } catch (err) {
      addToast(`Failed to map GitHub user: ${err.message}`, 'error');
    } finally {
      setSavingGh(prev => ({ ...prev, [userId]: false }));
    }
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      await apiService.updateMemberRole(teamId, userId, newRole);
      addToast(`Updated member role to ${newRole}!`, 'success');
      loadTeamData();
      if (onDataChanged) onDataChanged();
    } catch (err) {
      addToast(`Failed to change role: ${err.message}`, 'error');
    }
  };

  const handleRemoveMember = async (userId, memberName) => {
    if (!window.confirm(`Are you sure you want to remove ${memberName} from this team?`)) return;
    try {
      await apiService.removeTeamMember(teamId, userId);
      addToast(`Removed ${memberName} from team`, 'info');
      loadTeamData();
      if (onDataChanged) onDataChanged();
    } catch (err) {
      addToast(`Failed to remove member: ${err.message}`, 'error');
    }
  };

  return (
    <Card
      title="Team Members & GitHub Contributor Mapping"
      subtitle="Associate SquadSync members with GitHub handles to correlate task workload with repository activity"
      headerAction={
        <Button
          size="sm"
          variant="primary"
          icon={UserPlus}
          onClick={() => setIsInviteModalOpen(true)}
        >
          Invite Member
        </Button>
      }
    >
      <div className="space-y-6">
        {/* Active Members Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Member</th>
                <th className="py-2.5 px-3">Role</th>
                <th className="py-2.5 px-3">Mapped GitHub Username</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {members.map((m) => (
                <tr key={m.user_id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-700 font-bold flex items-center justify-center text-xs">
                        {m.name?.charAt(0) || 'U'}
                      </div>
                      <div>
                        <span className="font-semibold text-slate-900 block">{m.name}</span>
                        <span className="text-[11px] text-slate-400 block">{m.email}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <select
                      value={m.role}
                      onChange={(e) => handleRoleChange(m.user_id, e.target.value)}
                      className="px-2 py-1 text-xs bg-slate-50 border border-slate-200 rounded-md font-medium text-slate-800"
                    >
                      <option value="developer">Developer</option>
                      <option value="team_lead">Team Lead</option>
                      <option value="reviewer">Reviewer</option>
                      <option value="viewer">Viewer</option>
                    </select>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <div className="relative">
                        <Github className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
                        <input
                          type="text"
                          placeholder="github_username"
                          value={editingGh[m.user_id] ?? ''}
                          onChange={(e) =>
                            setEditingGh(prev => ({ ...prev, [m.user_id]: e.target.value }))
                          }
                          className="pl-7 pr-2 py-1 text-xs bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-purple-500 w-44"
                        />
                      </div>
                      <button
                        onClick={() => handleSaveGithub(m.user_id)}
                        disabled={savingGh[m.user_id]}
                        className="px-2 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 text-xs font-semibold rounded-md border border-purple-200 transition-colors flex items-center gap-1"
                        title="Save GitHub mapping"
                      >
                        <Save className="w-3 h-3" />
                        <span>Save</span>
                      </button>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right whitespace-nowrap">
                    {user?.id !== m.user_id && (
                      <button
                        onClick={() => handleRemoveMember(m.user_id, m.name)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded transition-colors"
                        title="Remove member from team"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Sent Invitations Status */}
        {invitations.length > 0 && (
          <div className="pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-purple-600" />
              <span>Team Invitations ({invitations.length})</span>
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3">Invited Email</th>
                    <th className="py-2 px-3">Assigned Role</th>
                    <th className="py-2 px-3">Status</th>
                    <th className="py-2 px-3">Invited By</th>
                    <th className="py-2 px-3">Invited Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {invitations.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-2 px-3 font-medium text-slate-900">{inv.email}</td>
                      <td className="py-2 px-3 text-slate-600 capitalize">{inv.role}</td>
                      <td className="py-2 px-3">
                        <Badge
                          variant={
                            inv.status === 'accepted'
                              ? 'emerald'
                              : inv.status === 'pending'
                              ? 'amber'
                              : 'rose'
                          }
                          size="sm"
                        >
                          {inv.status}
                        </Badge>
                      </td>
                      <td className="py-2 px-3 text-slate-500">{inv.inviter_name || 'Team Lead'}</td>
                      <td className="py-2 px-3 text-slate-400">{formatDate(inv.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <InviteMemberModal
        isOpen={isInviteModalOpen}
        onClose={() => setIsInviteModalOpen(false)}
        teamId={teamId}
        onMemberInvited={() => loadTeamData()}
      />
    </Card>
  );
}
